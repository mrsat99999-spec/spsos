#!/bin/bash
# ============================================================
# SPS OS — Automated ISO Build Script
# ============================================================
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
BUILD_DIR="$PROJECT_DIR/build"
ISO_OUT="$PROJECT_DIR/iso-output"
VERSION="1.0"
ARCH="amd64"

banner() {
  echo -e "${CYAN}"
  echo "╔══════════════════════════════════════════════╗"
  echo "║           SPS OS — ISO Builder               ║"
  echo "║        Version $VERSION — 64-bit               ║"
  echo "╚══════════════════════════════════════════════╝"
  echo -e "${NC}"
}

log()  { echo -e "${GREEN}[SPS-BUILD]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
err()  { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

check_root() {
  [[ $EUID -ne 0 ]] && err "Run as root: sudo ./scripts/build.sh"
}

install_deps() {
  log "Installing build dependencies..."
  apt-get update -q
  apt-get install -y \
    live-build \
    debootstrap \
    squashfs-tools \
    xorriso \
    isolinux \
    syslinux-efi \
    grub-pc-bin \
    grub-efi-amd64-bin \
    mtools \
    curl \
    wget \
    git \
    genisoimage \
    python3 \
    python3-pip 2>/dev/null || true
  log "Dependencies installed."
}

setup_build() {
  log "Setting up build directory..."
  rm -rf "$BUILD_DIR"
  mkdir -p "$BUILD_DIR"
  cp -r "$PROJECT_DIR/config" "$BUILD_DIR/"
  cp -r "$PROJECT_DIR/hooks" "$BUILD_DIR/"
  cp -r "$PROJECT_DIR/includes.chroot" "$BUILD_DIR/"
  cp -r "$PROJECT_DIR/package-lists" "$BUILD_DIR/"
  mkdir -p "$ISO_OUT"
}

configure_lb() {
  log "Configuring live-build..."
  cd "$BUILD_DIR"

  lb config \
    --architectures "$ARCH" \
    --distribution noble \
    --archive-areas "main restricted universe multiverse" \
    --apt-recommends true \
    --bootappend-live "boot=live components quiet splash hostname=sps-os username=spsuser" \
    --iso-application "SPS OS" \
    --iso-preparer "SPS OS Project" \
    --iso-publisher "SPS OS" \
    --iso-volume "SPS-OS-$VERSION" \
    --linux-flavours generic \
    --mirror-bootstrap "http://archive.ubuntu.com/ubuntu/" \
    --mirror-chroot "http://archive.ubuntu.com/ubuntu/" \
    --mirror-binary "http://archive.ubuntu.com/ubuntu/" \
    --mirror-binary-security "http://security.ubuntu.com/ubuntu/" \
    --updates true \
    --security true \
    --firmware-chroot true \
    --memtest none \
    --win32-loader false \
    2>&1 | tail -5

  log "live-build configured."
}

build_iso() {
  log "Building SPS OS ISO (this takes 20-40 minutes)..."
  cd "$BUILD_DIR"
  lb build 2>&1 | tee "$ISO_OUT/build.log"

  # Find and rename the ISO
  ISO_FILE=$(find "$BUILD_DIR" -name "*.iso" 2>/dev/null | head -1)
  if [[ -n "$ISO_FILE" ]]; then
    FINAL_ISO="$ISO_OUT/sps-os-${VERSION}-${ARCH}.iso"
    mv "$ISO_FILE" "$FINAL_ISO"
    SIZE=$(du -h "$FINAL_ISO" | cut -f1)
    log "✓ ISO built successfully!"
    log "  Location : $FINAL_ISO"
    log "  Size     : $SIZE"
    sha256sum "$FINAL_ISO" > "${FINAL_ISO}.sha256"
    log "  Checksum : ${FINAL_ISO}.sha256"
  else
    err "ISO not found. Check $ISO_OUT/build.log for errors."
  fi
}

banner
check_root
install_deps
setup_build
configure_lb
build_iso

echo -e "\n${GREEN}${BOLD}╔════════════════════════════════════╗${NC}"
echo -e "${GREEN}${BOLD}║   SPS OS ISO build complete! 🎉    ║${NC}"
echo -e "${GREEN}${BOLD}╚════════════════════════════════════╝${NC}"
echo -e "ISO: ${CYAN}$ISO_OUT/sps-os-${VERSION}-${ARCH}.iso${NC}\n"
