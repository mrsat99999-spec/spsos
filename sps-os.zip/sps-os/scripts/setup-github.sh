#!/bin/bash
# SPS OS — GitHub Setup Script
# Run this on your Ubuntu server after cloning

set -e

CYAN='\033[0;36m'; GREEN='\033[0;32m'; BOLD='\033[1m'; NC='\033[0m'

echo -e "${CYAN}${BOLD}SPS OS — GitHub Repository Setup${NC}"
echo "=================================="

read -p "Your GitHub username: " GH_USER
read -p "Your repository name [sps-os]: " REPO_NAME
REPO_NAME=${REPO_NAME:-sps-os}

# Init git
if [[ ! -d .git ]]; then
  git init
  git branch -M main
fi

# Add .gitignore
cat > .gitignore << 'EOF'
build/
iso-output/*.iso
iso-output/build.log
*.tmp
__pycache__/
*.pyc
.DS_Store
EOF

git add .
git commit -m "Initial SPS OS commit" 2>/dev/null || git commit -m "Update SPS OS"

echo -e "\n${CYAN}Creating GitHub repository...${NC}"
echo "Go to: https://github.com/new"
echo "Create a repo named: $REPO_NAME"
echo ""
read -p "Press Enter when done..."

git remote remove origin 2>/dev/null || true
git remote add origin "https://github.com/$GH_USER/$REPO_NAME.git"
git push -u origin main

echo -e "\n${GREEN}✓ SPS OS pushed to GitHub!${NC}"
echo -e "URL: ${CYAN}https://github.com/$GH_USER/$REPO_NAME${NC}"
echo ""
echo "To build on your Ubuntu server:"
echo "  git clone https://github.com/$GH_USER/$REPO_NAME"
echo "  cd $REPO_NAME"
echo "  sudo ./scripts/build.sh"
