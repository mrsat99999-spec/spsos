#!/bin/bash
# SPS OS — Quick build after cloning on Ubuntu server
# Usage: bash quickbuild.sh

set -e

echo "SPS OS — Quick Build"
echo "===================="

# Install deps
sudo apt-get update -q
sudo apt-get install -y live-build debootstrap squashfs-tools xorriso \
  isolinux syslinux-efi grub-pc-bin grub-efi-amd64-bin mtools genisoimage

# Make scripts executable
chmod +x scripts/build.sh
chmod +x scripts/setup-github.sh
chmod +x hooks/*.hook.chroot 2>/dev/null || true
chmod +x includes.chroot/usr/local/bin/* 2>/dev/null || true

# Build
sudo ./scripts/build.sh
