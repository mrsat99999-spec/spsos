# SPS OS

**SPS OS** is a custom Linux-based desktop operating system with its own identity, branding, terminal, and tools.

## Features
- Full GNOME desktop environment (branded as SPS Desktop)
- SPS Command Executor — custom feature-rich terminal
- SPS Software Center
- SPS System Settings
- Custom boot splash, login screen, and wallpaper
- 64-bit ISO bootable on Hyper-V, VirtualBox, VMware, and real hardware
- Auto-installs all required packages on build

## Requirements (build machine — your Ubuntu server)
- Ubuntu 22.04 or 24.04 (server or desktop)
- 20 GB free disk space
- Internet connection
- 4 GB RAM minimum

## Quick Start

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_USERNAME/sps-os.git
cd sps-os

# 2. Run the automated build
chmod +x scripts/build.sh
sudo ./scripts/build.sh

# 3. Your ISO will be at:
#    iso-output/sps-os-1.0-amd64.iso
```

## Hyper-V Setup
1. Create a new VM → Generation 2
2. Disable Secure Boot (or set to "Microsoft UEFI Certificate Authority")
3. Attach the ISO as DVD drive
4. Set RAM to 2048 MB minimum
5. Boot and install!

## Directory Structure
```
sps-os/
├── config/               # live-build configuration
├── hooks/                # build-time scripts
├── includes.chroot/      # files copied into the live system
│   ├── etc/sps-os/       # SPS OS system config
│   ├── usr/local/bin/    # SPS tools & terminal
│   └── usr/share/        # icons, wallpapers, themes
├── package-lists/        # packages to install
├── scripts/              # build automation
└── iso-output/           # built ISO goes here
```

## License
SPS OS is built on top of Debian/Ubuntu packages (GPL licensed).
Your custom code and branding © SPS OS Project.
