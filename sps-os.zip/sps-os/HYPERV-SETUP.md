# SPS OS — Hyper-V Setup Guide

## Step-by-Step: Running SPS OS in Hyper-V

### 1. Before you start
- Have the SPS OS ISO file ready
- Open **Hyper-V Manager** on Windows

### 2. Create a new Virtual Machine
1. Right-click your host → **New → Virtual Machine**
2. Click **Next**
3. Name: `SPS OS`
4. Location: choose where to store it
5. Click **Next**

### 3. Choose Generation
- Select **Generation 2** (supports UEFI, faster)
- Click **Next**

### 4. Memory
- Startup memory: `2048 MB` minimum (4096 MB recommended)
- ✅ Enable Dynamic Memory (optional)

### 5. Network
- Select your virtual switch (or create one)

### 6. Virtual Hard Disk
- Size: `25 GB` minimum (50 GB recommended)

### 7. Installation Options
- Select **Install from image file (.iso)**
- Browse to your `sps-os-1.0-amd64.iso`

### 8. IMPORTANT — Disable Secure Boot
After creating the VM:
1. Right-click VM → **Settings**
2. Go to **Security**
3. Uncheck **Enable Secure Boot** OR
   Set template to: `Microsoft UEFI Certificate Authority`

### 9. Add Hyper-V Integration Services
SPS OS includes `hyperv-daemons` and `linux-azure` packages
which automatically enable:
- Enhanced Session Mode
- Clipboard sharing
- Dynamic memory
- Time sync
- Shutdown integration

### 10. Boot SPS OS
1. Start the VM
2. SPS OS boots to live desktop
3. Click **Install SPS OS** on the desktop
4. Follow the installer

### Recommended VM Settings
| Setting | Value |
|---------|-------|
| Generation | 2 (UEFI) |
| RAM | 4096 MB |
| CPUs | 2+ |
| Disk | 50 GB |
| Network | External switch |
| Secure Boot | Disabled |
| Checkpoints | Enabled |

### Enhanced Session Mode
For clipboard + better resolution:
1. VM Settings → Integration Services → ✅ Guest Services
2. In Hyper-V Manager → View → Enhanced Session (when VM is running)
